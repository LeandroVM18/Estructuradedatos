//#include "StdAfx.h"
#include <iostream>
#include <fstream>
#include <conio.h>
#include "ABMamigo.h"

using namespace std;

int opt=1;

void main() {
		ABMamigo* amig = new ABMamigo("amigOO.dat");
	while (opt != 0) {
		cout << "1.- Para adicionar amigo" << endl;
		cout << "2.- Para listar amigo" << endl;
		cout << "3.- Para buscar amigo" << endl;
		cout << "4.- Para eliminar amigo" << endl;
		cout << "5.- Para modificar amigo" << endl;
		cout << "6.- Para listar amigo" << endl;
		cout << "0.- Para salir" << endl;
		cout << "Selecciona una opcion" << endl;
		cin >> opt;

		switch (opt) {
		case 1: amig->adicionarNuevo();
			break;
		case 2: amig->listar();
			break;
		case 3: amig->buscarReg();
			break;
		case 4: amig->eliminarReg();
			break;
		case 5: amig->modificarReg();
			break;
		case 6: amig->listar();
			break;
		case 0: cout<<"Saliste"<<endl;
			break;
		default: cout << "Opcion incorrecta" << endl;
			break;
		}
	}
	//getch();
}
